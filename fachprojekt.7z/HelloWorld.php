<?php 

class HelloWorld
{

    public function sayHi()
    {
        return "Hello World";
    }
}