<?php 
// use the following namespace
use PHPUnit\Framework\TestCase;

class HelloWorldTest extends TestCase
{

    public function testSayHi()
    {
        $this->assertTrue(true); 
    }
}